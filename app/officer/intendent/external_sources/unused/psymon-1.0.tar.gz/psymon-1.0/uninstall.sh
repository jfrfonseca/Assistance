#!/bin/bash
echo "Start uninstallation of psymon..."
rm -f /usr/share/applications/psymon.desktop
rm -rf /opt/psymon
echo "Done!"
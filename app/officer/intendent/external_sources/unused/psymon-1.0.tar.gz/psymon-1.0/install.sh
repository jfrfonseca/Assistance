#!/bin/bash
echo "Start installation of psymon..."

mkdir -p /opt/psymon
cp -r psymondatapack/ /opt/psymon/
cp -r docs/ /opt/psymon/
cp psymon /opt/psymon/
cp uninstall.sh /opt/psymon/
cp psymon.desktop /usr/share/applications/

echo "Done!"
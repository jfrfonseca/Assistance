rm ./tests/*.pyc 2> /dev/null
nosetests tests/*

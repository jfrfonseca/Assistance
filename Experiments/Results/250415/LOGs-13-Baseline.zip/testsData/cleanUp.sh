#!/bin/bash
# Clean ALL LOGS!!! USE WITH CAUTION!!!
# CWD is build/testsData
# Macros

# Authorizes the Binary
rm ../LOGs.zip
rm ../testsResults/*
rm ../LOG/*
rm -rf ../AssistanceApps/runtimeIO/*

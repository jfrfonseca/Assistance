#!/bin/bash
#Installing dependencies
pip install --no-index --find-links=pkgOfficer/external-sources/used/psutil-2.2.1-cp27-none-win_amd64.whl psutil
#running the test
python testAssistance.py

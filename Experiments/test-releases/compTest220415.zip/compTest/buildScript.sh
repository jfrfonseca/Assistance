#!/bin/bash
#Compiles Assistance! The first argument must be the name of the build!
cxfreeze ../../../app/testAssistance.py --target-dir build


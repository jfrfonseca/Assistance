#!/bin/bash
# CHMOD's Assistance in order to allow it to run
# CWD is build/testsData
# Macros
AUTH_LEVEL=755
# Authorizes
chmod ${AUTH_LEVEL} authorize.sh
./authorize.sh
# Cleans
./cleanUp.sh
# Come back
cd ../
# tests functionality
./testAssistance -f
# prints own IP
ifconfig
# waits for it
sleep 120
# Starts the server
./testAssistance -s
